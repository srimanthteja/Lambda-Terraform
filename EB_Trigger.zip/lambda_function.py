import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    print(event)
    logger.info("success flow")
    logger.error("define your try catch error")
    logger.critical("define your critical situation")
    print("success")
    print(context)
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
